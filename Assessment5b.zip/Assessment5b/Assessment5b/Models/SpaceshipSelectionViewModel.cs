﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assessment5b.Models
{
    public class SpaceshipSelectionViewModel
    {
        public string Name { get; set; }


    }
}
