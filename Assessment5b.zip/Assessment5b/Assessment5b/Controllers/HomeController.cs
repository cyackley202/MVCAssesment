﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Assessment5b.Models;

namespace Assessment5b.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        
        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult Welcome()
        {
            return View();
        }

        public IActionResult SubmitAge(WelcomeViewModel model)
        {
            if (model.Age >= 426 && model.Age <= 889)
            {
                return RedirectToAction("SpaceshipSelection");
            }
            else
            {
                return RedirectToAction("Sorry", model);
            }
        }

        public IActionResult Sorry(WelcomeViewModel model)
        {
            SorryViewModel sorry = new SorryViewModel();
            sorry.Age = model.Age;
            return View(sorry);
        }

        public IActionResult SpaceshipSelection()
        {
            
            return View(new SpaceshipSelectionViewModel());
        }

        public IActionResult Spaceship(SpaceshipSelectionViewModel model)
        {
            SpaceshipViewModel falcon = new SpaceshipViewModel();
            falcon.Ship = model.Name;

            return View(falcon);
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
